import { SaveHtmlPipe } from './save-html.pipe';

describe('SaveHtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new SaveHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
