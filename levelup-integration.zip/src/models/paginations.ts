export class Paginations {
  limit: number;
  page: number;
  id: string;
  fcm: string;
}


export class ScheduleBooking{
  date: Date;
  day: number;
  package: string;
  category: string;
}
