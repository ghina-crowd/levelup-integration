export interface ContactModel {
  name: string;
  details: string;
  email: string;

}
