export interface EventModel {
  _id: string;
  title: string;
  description: string;
  date: Date;
  image: string;
}
