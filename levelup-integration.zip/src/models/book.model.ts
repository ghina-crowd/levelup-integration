export class BookModel{
  package: string;
  validity: number;
}
