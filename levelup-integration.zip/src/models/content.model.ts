export interface ContentModel {
  content: string;
  cover: string;
  image: string;
  type: string;
  _id: string;
}
