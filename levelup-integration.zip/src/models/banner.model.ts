export interface BannerModel {
  _id: string;
  image: string;
  active: boolean;
}
