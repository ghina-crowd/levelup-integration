export const environment = {
  production: false,
  apiURI: 'https://crowd-server.com/levelup/v1',
  appUrl: 'https://crowd-server.com/levelup/v1',
  baseUrl: 'https://crowd-server.com/levelup/v1',
  fileUrl: 'https://crowd-server.com/levelup/uploads/original/',
  firebaseConfig: {
    apiKey: "AIzaSyC9O5XnDgopFaMONPpTV8Vnt7MCmp6ZP40",
    authDomain: "deliveryq-8ccda.firebaseapp.com",
    databaseURL: "https://deliveryq-8ccda.firebaseio.com",
    projectId: "deliveryq-8ccda",
    storageBucket: "deliveryq-8ccda.appspot.com",
    messagingSenderId: "412977740483",
    appId: "1:412977740483:web:7ba00c16e608d08c9ec076",
    measurementId: "G-KL9HRXQE08"
  }

};
